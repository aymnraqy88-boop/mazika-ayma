package com.ayman.mazika

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.TimeUnit

data class Song(val title: String, val artist: String, val uri: Uri, val online: Boolean = false)

class MainActivity : AppCompatActivity() {
    private val songs = mutableListOf<Song>()
    private val shown = mutableListOf<Song>()
    private val favorites = mutableSetOf<String>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var status: TextView
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val prefs by lazy { getSharedPreferences("mazika", MODE_PRIVATE) }
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadSongs() else status.text = "اسمح بالوصول لملفات الصوت لعرض أغانيك."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())
        buildUi()
        connectPlayer()
        requestAudioPermission()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            setBackgroundColor(0xFF050B14.toInt())
        }
        val title = TextView(this).apply {
            text = "♫  مزيكا أيمن"
            textSize = 28f; gravity = Gravity.CENTER
            setTextColor(0xFF16A5FF.toInt()); setPadding(0, 10, 0, 14)
        }
        status = TextView(this).apply {
            text = "موسيقاك في مكان واحد"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(0xFFB8C7D9.toInt()); setPadding(0, 0, 0, 12)
        }
        search = EditText(this).apply {
            hint = "ابحث عن أغنية أو فنان..."
            setSingleLine(true); setTextColor(-1); setHintTextColor(0xFF91A0B5.toInt())
            setBackgroundColor(0xFF101D2D.toInt())
            setPadding(14, 8, 14, 8)
        }
        search.addTextChangedListener(SimpleTextWatcher { renderSongs() })
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(actionButton("كل الأغاني") { renderSongs() }, weightParams())
        buttons.addView(actionButton("المفضلة ♥") {
            shown.clear(); shown.addAll(songs.filter { favorites.contains(it.uri.toString()) }); renderList(shown)
        }, weightParams())
        buttons.addView(actionButton("إضافة رابط") { addOnlineUrl() }, weightParams())
        val playerControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        playerControls.addView(actionButton("⏮") { controller?.seekToPreviousMediaItem() }, weightParams())
        playerControls.addView(actionButton("▶ / ⏸") {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }, weightParams())
        playerControls.addView(actionButton("⏭") { controller?.seekToNextMediaItem() }, weightParams())
        playerControls.addView(actionButton("مؤقت") { setTimer() }, weightParams())
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(title)
        root.addView(status)
        root.addView(search, LinearLayout.LayoutParams(-1, -2))
        root.addView(buttons)
        root.addView(playerControls)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; setTextColor(-1); setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF087DE0.toInt()))
        setOnClickListener { action() }
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadSongs()
        else permissionLauncher.launch(permission)
    }

    private fun loadSongs() {
        songs.clear()
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                songs.add(Song(cursor.getString(titleCol) ?: "بدون اسم", cursor.getString(artistCol) ?: "فنان غير معروف",
                    ContentUris.withAppendedId(collection, id)))
            }
        }
        status.text = "عدد الأغاني على جهازك: ${songs.size}"
        renderSongs()
    }

    private fun renderSongs() {
        val q = search.text?.toString()?.trim()?.lowercase().orEmpty()
        renderList(songs.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) })
    }

    private fun renderList(items: List<Song>) {
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply { text = "مفيش أغاني ظاهرة. جرّب البحث أو أضف رابطًا قانونيًا."; setTextColor(-1); textSize = 15f; setPadding(8, 20, 8, 20) })
            return
        }
        items.forEach { song ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(4, 5, 4, 5)
            }
            val info = TextView(this).apply {
                text = "${song.title}\n${song.artist}"; textSize = 15f; setTextColor(-1)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setPadding(8, 8, 8, 8)
                setOnClickListener { playSong(song) }
            }
            val fav = Button(this).apply {
                text = if (favorites.contains(song.uri.toString())) "♥" else "♡"
                setTextColor(0xFF16A5FF.toInt())
                setOnClickListener {
                    val key = song.uri.toString()
                    if (!favorites.add(key)) favorites.remove(key)
                    prefs.edit().putStringSet("favorites", favorites.toSet()).apply()
                    text = if (favorites.contains(key)) "♥" else "♡"
                }
            }
            val play = Button(this).apply {
                text = "تشغيل"; setOnClickListener { playSong(song) }
            }
            row.addView(info); row.addView(fav); row.addView(play)
            list.addView(row)
            val line = View(this).apply { setBackgroundColor(0xFF1A2D42.toInt()) }
            list.addView(line, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun playSong(song: Song) {
        val c = controller
        if (c == null) { status.text = "جاري تجهيز مشغل الموسيقى، حاول مرة أخرى."; return }
        val item = MediaItem.Builder().setUri(song.uri).setMediaMetadata(
            MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).build()
        ).build()
        c.setMediaItem(item); c.prepare(); c.play()
        status.text = "يتم التشغيل: ${song.title}"
    }

    private fun addOnlineUrl() {
        val input = EditText(this).apply { hint = "https:// رابط بث قانوني"; setSingleLine(true) }
        android.app.AlertDialog.Builder(this).setTitle("إضافة رابط موسيقى قانوني")
            .setMessage("الصق رابط بث مباشر أو ملف صوتي تملك حق استخدامه.")
            .setView(input).setNegativeButton("إلغاء", null)
            .setPositiveButton("إضافة") { _, _ ->
                val raw = input.text.toString().trim()
                if (!raw.startsWith("https://")) {
                    Toast.makeText(this, "استخدم رابط HTTPS صحيحًا", Toast.LENGTH_LONG).show(); return@setPositiveButton
                }
                val song = Song(raw.substringAfterLast('/').ifBlank { "بث عبر الإنترنت" }, "مصدر عبر الإنترنت", Uri.parse(raw), true)
                songs.add(0, song)
                renderSongs()
                playSong(song)
            }.show()
    }

    private fun setTimer() {
        val choices = arrayOf("15 دقيقة", "30 دقيقة", "45 دقيقة", "60 دقيقة")
        val minutes = intArrayOf(15, 30, 45, 60)
        android.app.AlertDialog.Builder(this).setTitle("إيقاف الموسيقى بعد")
            .setItems(choices) { _, which ->
                val delay = minutes[which].toLong() * 60 * 1000
                android.os.Handler(mainLooper).postDelayed({
                    controller?.pause()
                    Toast.makeText(this, "تم إيقاف الموسيقى بالمؤقت", Toast.LENGTH_LONG).show()
                }, delay)
                Toast.makeText(this, "تم ضبط المؤقت: ${minutes[which]} دقيقة", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({ controller = controllerFuture?.get() }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}
